/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.VeiculoDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.persistence.Persistence;
import model.Veiculo;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneBuscarVeiculoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField tfPlaca;
    @FXML
    private Label labelIdVeiculo;
    @FXML
    private Button btBuscar;
    @FXML
    private Button btSelecionar;
    @FXML
    private Button btCancelar;
    @FXML
    private TableView<Veiculo> tabelaVeiculos;
    @FXML
    private TableColumn<Veiculo, String> tcIdVeiculo;
    @FXML
    private TableColumn<Veiculo, String> tcPlaca;
    @FXML
    private TableColumn<Veiculo, String> tcModelo;
    @FXML
    private TableColumn<Veiculo, String> tcProprietario;
    
    private List<Veiculo> listVeiculos;
    private ObservableList<Veiculo> obsListVeiculos;
    
    VeiculoDAO veiculoDAO = 
        new VeiculoDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    
    private Stage dialogStage;
    private Veiculo veiculo;
    public static Veiculo veiculoTemp;
    
@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            listVeiculos = veiculoDAO.getAll();
            obsListVeiculos = FXCollections.observableArrayList(listVeiculos);
            tabelaVeiculos.setItems(obsListVeiculos);
            carregarTabelaVeiculos();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneBuscarVeiculoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaVeiculos.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaVeiculo(newValue));
        
    }

    public void carregarTabelaVeiculos() throws DAOException {
        tcIdVeiculo.setCellValueFactory(new PropertyValueFactory("id"));
        tcPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
        tcModelo.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getModeloId().getDescricao()));
        tcProprietario.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getClienteId().getNome()));
    }
    
    public void selecionarItemTabelaVeiculo(Veiculo veiculo) {
        if (veiculo != null){
            labelIdVeiculo.setText(String.valueOf(veiculo.getId()));
            tfPlaca.setText(String.valueOf(veiculo.getPlaca()));
            //veiculo = tabelaVeiculos.getSelectionModel().getSelectedItem();
        }
        else {
            limparCampos();
        }
    }

    @FXML
    public void handleBtBuscarVeiculo() throws IOException, DAOException {
        if (tfPlaca.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha o campo.");
            alert.show();
        }
        else {
            listVeiculos = veiculoDAO.getByNearPlaca(tfPlaca.getText());
            obsListVeiculos = FXCollections.observableArrayList(listVeiculos);
            tabelaVeiculos.setItems(obsListVeiculos);
            carregarTabelaVeiculos();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtSelecionarVeiculo() throws IOException, DAOException {
        FXMLAnchorPaneBuscarVeiculoController.veiculoTemp = tabelaVeiculos.getSelectionModel().getSelectedItem();
        if (FXMLAnchorPaneBuscarVeiculoController.veiculoTemp == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um veiculo.");
            alert.show();    
        } else {
            dialogStage.close();
        }
        
    }
    
    @FXML
    public void handleBtCancelar() throws IOException, DAOException {
        dialogStage.close();
        // mesmo do anterior, retorna para vbox
    }
    
    public void limparCampos() {
        veiculo = null;
        labelIdVeiculo.setText("");
        tfPlaca.setText("");
    }

    /**
     * @return the dialogStage
     */
    public Stage getDialogStage() {
        return dialogStage;
    }

    /**
     * @param dialogStage the dialogStage to set
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }
}
