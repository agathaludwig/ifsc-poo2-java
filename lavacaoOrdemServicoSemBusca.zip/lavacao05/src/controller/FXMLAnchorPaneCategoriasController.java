/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.CategoriaDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Categoria;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneCategoriasController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroCategoria;
    @FXML
    private TextField tfNomeCategoria;
    @FXML
    private TextField tfTaxaDesconto;
    @FXML
    private Label labelIdCategoria;
    @FXML
    private Button btInserirCategoria;
    @FXML
    private Button btAlterarCategoria;
    @FXML
    private Button btRemoverCategoria;
    @FXML
    private TableView<Categoria> tabelaCategorias;
    @FXML
    private TableColumn<Categoria, String> tcIdCategoria;
    @FXML
    private TableColumn<Categoria, String> tcNomeCategoria;
    @FXML
    private TableColumn<Categoria, String> tcTaxaCategoria;
    
    private List<Categoria> listCategorias;
    private ObservableList<Categoria> obsListCategorias;

    Categoria categoria;
        // = new Categoria();
    
    CategoriaDAO categoriaDAO = 
        new CategoriaDAO(Persistence.createEntityManagerFactory("lavacao05PU"));

@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarTabelaCategorias();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneCategoriasController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaCategorias.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaCategoria(newValue));
        
    }    
     
    public void carregarTabelaCategorias() throws DAOException {
        tcIdCategoria.setCellValueFactory(new PropertyValueFactory("id"));
        tcNomeCategoria.setCellValueFactory(new PropertyValueFactory("nome"));
        tcTaxaCategoria.setCellValueFactory(new PropertyValueFactory("taxaDesconto"));
                
        listCategorias = categoriaDAO.getAll();
        
        obsListCategorias = FXCollections.observableArrayList(listCategorias);
        tabelaCategorias.setItems(obsListCategorias);
        tabelaCategorias.refresh();

    }
    
    public void selecionarItemTabelaCategoria(Categoria categoria) {
        if (categoria != null){
            labelIdCategoria.setText(String.valueOf(categoria.getId()));
            tfNomeCategoria.setText(String.valueOf(categoria.getNome()));
            tfTaxaDesconto.setText(String.valueOf(categoria.getTaxaDesconto()));
        }
        else {
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtInserirCategoria() throws IOException, DAOException {
        if (tfNomeCategoria.getText().equals("") || tfTaxaDesconto.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Categoria categoria = new Categoria();
            categoria.setNome(tfNomeCategoria.getText());
            categoria.setTaxaDesconto(Double.parseDouble(tfTaxaDesconto.getText()));
            categoriaDAO.salvar(categoria);
            carregarTabelaCategorias();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarCategoria() throws IOException, DAOException {
        Categoria categoria = tabelaCategorias.getSelectionModel().getSelectedItem();
        if (categoria != null){
            categoria.setNome(tfNomeCategoria.getText());
            categoria.setTaxaDesconto(Double.parseDouble(tfTaxaDesconto.getText()));
            categoriaDAO.alterar(categoria);
            carregarTabelaCategorias(); 
            // porque nao atualiza a tabela se faz o getAll?
            limparCampos();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um categoria.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverCategoria() throws IOException, DAOException {
        Categoria categoria = tabelaCategorias.getSelectionModel().getSelectedItem();
        if (categoria != null) {
            categoriaDAO.excluir(categoria.getId());
            carregarTabelaCategorias();
            limparCampos();
            // usando o método excluir com parametro categoria nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um categoria.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        categoria = null;
        labelIdCategoria.setText("");
        tfNomeCategoria.setText("");
        tfTaxaDesconto.setText("");
    }
}