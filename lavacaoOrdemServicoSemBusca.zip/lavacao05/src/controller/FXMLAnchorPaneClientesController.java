/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ClienteDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Cliente;
import model.PessoaFisica;
import model.PessoaJuridica;

/**
 * FXML Controller class
 *
 * @author agatha
 */

// duvidas
// selecionarItemTabelaClientes -> qual o erro
// como usar o método da classe filha (selecionarItemTabelaClientes e handleBtAlterarCliente)
// 
public class FXMLAnchorPaneClientesController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroCliente;
    @FXML
    private Label labelIdCliente;
    @FXML
    private TextField tfNomeCliente;
    @FXML
    private TextField tfTelefoneCliente;
    @FXML
    private TextField tfEmailCliente;
    @FXML
    private ToggleGroup tgTipo;
    @FXML
    private RadioButton rbPessoaFisica;
    @FXML
    private RadioButton rbPessoaJuridica;
    @FXML
    private TextField tfCpf;
    @FXML
    private TextField tfCnpj;
    @FXML
    private TextField tfIe;
    @FXML
    private Button btInserirCliente;
    @FXML
    private Button btAlterarCliente;
    @FXML
    private Button btRemoverCliente;
    @FXML
    private TableView<Cliente> tabelaClientes;
    @FXML
    private TableColumn<Cliente, String> tcIdCliente;
    @FXML
    private TableColumn<Cliente, String> tcNomeCliente;
    @FXML
    private TableColumn<Cliente, String> tcEmailCliente; 
    
    private List<Cliente> listClientes;
    private ObservableList<Cliente> obsListClientes;

    Cliente cliente;
        // = new Cliente();
    
    ClienteDAO clienteDAO = 
        new ClienteDAO(Persistence.createEntityManagerFactory("lavacao05PU"));

@Override
    public void initialize(URL url, ResourceBundle rb) {
        // como fazer o listen para alterar o estado do textfield
        try {
            carregarTabelaClientes();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneClientesController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaClientes.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaClientes(newValue));
    }    
     
    public void carregarTabelaClientes() throws DAOException {
        tcIdCliente.setCellValueFactory(new PropertyValueFactory("id"));
        tcNomeCliente.setCellValueFactory(new PropertyValueFactory("nome"));
        tcEmailCliente.setCellValueFactory(new PropertyValueFactory("email"));
                
        listClientes = clienteDAO.getAll();
        
        obsListClientes = FXCollections.observableArrayList(listClientes);
        tabelaClientes.setItems(obsListClientes);
        //tabelaClientes.refresh();
    }
    
    public void selecionarItemTabelaClientes(Cliente cliente) {
        if (cliente instanceof PessoaFisica){
            labelIdCliente.setText(String.valueOf(cliente.getId()));
            tfNomeCliente.setText(String.valueOf(cliente.getNome()));
            tfTelefoneCliente.setText(String.valueOf(cliente.getTelefone()));
            tfEmailCliente.setText(String.valueOf(cliente.getEmail()));
            rbPessoaFisica.setSelected(true);
            tfCnpj.setDisable(true);
            tfIe.setDisable(true);
            tfCpf.setDisable(false);
            tfCnpj.setText("");
            tfIe.setText("");
            tfCpf.setText(String.valueOf(((PessoaFisica)cliente).getCpf()));
        } else if (cliente instanceof PessoaJuridica){
            labelIdCliente.setText(String.valueOf(cliente.getId()));
            tfNomeCliente.setText(String.valueOf(cliente.getNome()));
            tfTelefoneCliente.setText(String.valueOf(cliente.getTelefone()));
            tfEmailCliente.setText(String.valueOf(cliente.getEmail()));
            rbPessoaJuridica.setSelected(true);
            tfCpf.setDisable(true);
            tfCpf.setText("");
            tfCnpj.setDisable(false);
            tfIe.setDisable(false);
            tfCnpj.setText(String.valueOf(((PessoaJuridica)cliente).getCnpj()));
            tfIe.setText(String.valueOf(((PessoaJuridica)cliente).getInscricaoEstadual()));
        } else {
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtInserirCliente() throws IOException, DAOException {
        if (tfNomeCliente.getText().equals("") && (tfCpf.getText().equals("") || tfCnpj.getText().equals(""))) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            if (tfCpf.getText().length()!=0) {
                PessoaFisica cliente = new PessoaFisica();
                cliente.setNome(tfNomeCliente.getText());
                cliente.setTelefone(tfTelefoneCliente.getText());
                cliente.setEmail(tfEmailCliente.getText());
                cliente.setCpf(tfCpf.getText());
                clienteDAO.salvar(cliente);
                carregarTabelaClientes();
                limparCampos();
            }
            else {
                PessoaJuridica cliente = new PessoaJuridica();
                cliente.setNome(tfNomeCliente.getText());
                cliente.setTelefone(tfTelefoneCliente.getText());
                cliente.setEmail(tfEmailCliente.getText());
                cliente.setCnpj(tfCnpj.getText());
                cliente.setInscricaoEstadual(tfIe.getText());
                clienteDAO.salvar(cliente);
                carregarTabelaClientes();
                limparCampos();
            }
        }
    }
    
    @FXML
    public void handleBtAlterarCliente() throws IOException, DAOException {
        Cliente cliente = tabelaClientes.getSelectionModel().getSelectedItem();
        if (cliente != null){
            if (cliente instanceof PessoaFisica) {
                cliente.setNome(tfNomeCliente.getText());
                cliente.setTelefone(tfTelefoneCliente.getText());
                cliente.setEmail(tfEmailCliente.getText());
                ((PessoaFisica)cliente).setCpf(tfCpf.getText());
                clienteDAO.salvar(cliente);
                carregarTabelaClientes();
                limparCampos();
            }
            else {
                cliente.setNome(tfNomeCliente.getText());
                cliente.setTelefone(tfTelefoneCliente.getText());
                cliente.setEmail(tfEmailCliente.getText());
                ((PessoaJuridica)cliente).setCnpj(tfCnpj.getText());
                ((PessoaJuridica)cliente).setInscricaoEstadual(tfIe.getText());
                clienteDAO.salvar(cliente);
                carregarTabelaClientes();
                limparCampos();
            }
            clienteDAO.alterar(cliente);
            carregarTabelaClientes(); 
            limparCampos();
          }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um cliente.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverCliente() throws IOException, DAOException {
        Cliente cliente = tabelaClientes.getSelectionModel().getSelectedItem();
        if (cliente != null) {
            clienteDAO.excluir(cliente.getId());
            carregarTabelaClientes();
            limparCampos();
            // usando o método excluir com parametro cliente nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha uma cliente.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        cliente = null;
        labelIdCliente.setText("");
        tfNomeCliente.setText("");
        tfTelefoneCliente.setText("");
        tfEmailCliente.setText("");
        tfCpf.setText("");
        tfCnpj.setText("");
        tfIe.setText("");
        rbPessoaFisica.setSelected(false);
        rbPessoaJuridica.setSelected(false);
    }
    @FXML
    public void handleAlternarTextField()  {
        if (rbPessoaFisica.isSelected()) {
            tfCnpj.setDisable(true);
            tfIe.setDisable(true);
            tfCpf.setDisable(false);
        }
        if (rbPessoaJuridica.isSelected()) {
            tfCpf.setDisable(true);
            tfCnpj.setDisable(false);
            tfIe.setDisable(false);
        }
    }
}
