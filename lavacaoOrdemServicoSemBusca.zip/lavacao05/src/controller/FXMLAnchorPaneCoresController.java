/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.CorDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Cor;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneCoresController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroCor;
    @FXML
    private TextField tfCor;
    @FXML
    private Label labelIdCor;
    @FXML
    private Button btInserirCor;
    @FXML
    private Button btAlterarCor;
    @FXML
    private Button btRemoverCor;
    @FXML
    private TableView<Cor> tabelaCores;
    @FXML
    private TableColumn<Cor, String> tcIdCor;
    @FXML
    private TableColumn<Cor, String> tcCor;
    
    private List<Cor> listCores;
    private ObservableList<Cor> obsListCores;

    Cor cor;
        // = new Cor();
    
    CorDAO corDAO = 
        new CorDAO(Persistence.createEntityManagerFactory("lavacao05PU"));

@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarTabelaCores();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneCoresController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaCores.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaCores(newValue));
        
    }    
     
    public void carregarTabelaCores() throws DAOException {
        tcIdCor.setCellValueFactory(new PropertyValueFactory("id"));
        tcCor.setCellValueFactory(new PropertyValueFactory("cor"));
                
        listCores = corDAO.getAll();
        
        obsListCores = FXCollections.observableArrayList(listCores);
        tabelaCores.setItems(obsListCores);
        tabelaCores.refresh();

    }
    
    public void selecionarItemTabelaCores(Cor cor) {
        if (cor != null){
            labelIdCor.setText(String.valueOf(cor.getId()));
            tfCor.setText(String.valueOf(cor.getCor()));
        }
        else {
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtInserirCor() throws IOException, DAOException {
        if (tfCor.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Cor cor = new Cor();
            cor.setCor(tfCor.getText());
            corDAO.salvar(cor);
            carregarTabelaCores();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarCor() throws IOException, DAOException {
        Cor cor = tabelaCores.getSelectionModel().getSelectedItem();
        if (cor != null){
            cor.setCor(tfCor.getText());
            corDAO.alterar(cor);
            carregarTabelaCores(); 
            // porque nao atualiza a tabela se faz o getAll?
            limparCampos();
          }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha uma cor.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverCor() throws IOException, DAOException {
        Cor cor = tabelaCores.getSelectionModel().getSelectedItem();
        if (cor != null) {
            corDAO.excluir(cor.getId());
            carregarTabelaCores();
            limparCampos();
            // usando o método excluir com parametro cor nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha uma cor.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        cor = null;
        labelIdCor.setText("");
        tfCor.setText("");
    }
}
