/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.MarcaDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Marca;
import model.Marca;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneMarcasController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroMarca;
    @FXML
    private TextField tfNomeMarca;
    @FXML
    private Label labelIdMarca;
    @FXML
    private Button btInserirMarca;
    @FXML
    private Button btAlterarMarca;
    @FXML
    private Button btRemoverMarca;
    @FXML
    private TableView<Marca> tabelaMarcas;
    @FXML
    private TableColumn<Marca, String> tcIdMarca;
    @FXML
    private TableColumn<Marca, String> tcNomeMarca;
    //@FXML
    //private TableColumn<Marca, String> tcModelosMarca;
    // como faria isso?
    
    private List<Marca> listMarcas;
    private ObservableList<Marca> obsListMarcas;

    Marca marca;
        // = new Marca();
    
    MarcaDAO marcaDAO = 
        new MarcaDAO(Persistence.createEntityManagerFactory("lavacao05PU"));

@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarTabelaMarcas();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneMarcasController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaMarcas.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaMarcas(newValue));
        
    }    
     
    public void carregarTabelaMarcas() throws DAOException {
        tcIdMarca.setCellValueFactory(new PropertyValueFactory("id"));
        tcNomeMarca.setCellValueFactory(new PropertyValueFactory("nome"));
        //tcModelosMarca.setCellValueFactory(new PropertyValueFactory("modelos"));
                
        listMarcas = marcaDAO.getAll();
        
        obsListMarcas = FXCollections.observableArrayList(listMarcas);
        tabelaMarcas.setItems(obsListMarcas);
        tabelaMarcas.refresh();

    }
    
    public void selecionarItemTabelaMarcas(Marca marca) {
        if (marca != null){
            labelIdMarca.setText(String.valueOf(marca.getId()));
            tfNomeMarca.setText(String.valueOf(marca.getNome()));
            //tfModelosMarca.setText(String.valueOf(marca.getModeloCollection()));
        }
        else {
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtInserirMarca() throws IOException, DAOException {
        if (tfNomeMarca.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Marca marca = new Marca();
            marca.setNome(tfNomeMarca.getText());
            marcaDAO.salvar(marca);
            carregarTabelaMarcas();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarMarca() throws IOException, DAOException {
        Marca marca = tabelaMarcas.getSelectionModel().getSelectedItem();
        if (marca != null){
            marca.setNome(tfNomeMarca.getText());
            marcaDAO.alterar(marca);
            carregarTabelaMarcas(); 
            // porque nao atualiza a tabela se faz o getAll?
            limparCampos();
          }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha uma marca.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverMarca() throws IOException, DAOException {
        Marca marca = tabelaMarcas.getSelectionModel().getSelectedItem();
        if (marca != null) {
            marcaDAO.excluir(marca.getId());
            carregarTabelaMarcas();
            limparCampos();
            // usando o método excluir com parametro marca nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha uma marca.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        marca = null;
        labelIdMarca.setText("");
        tfNomeMarca.setText("");
    }
}
