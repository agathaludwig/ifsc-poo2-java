/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.CategoriaDAO;
import dao.MarcaDAO;
import dao.ModeloDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Categoria;
import model.Marca;
import model.Modelo;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneModelosController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroModelo;
    @FXML
    private TextField tfDescricaoModelo;
    @FXML
    private ComboBox cbMarca;
    @FXML
    private ComboBox cbCategoria;
    @FXML
    private Label labelIdModelo;
    @FXML
    private Button btInserirModelo;
    @FXML
    private Button btAlterarModelo;
    @FXML
    private Button btRemoverModelo;
    @FXML
    private TableView<Modelo> tabelaModelos;
    @FXML
    private TableColumn<Modelo, String> tcIdModelo;
    @FXML
    private TableColumn<Modelo, String> tcDescricaoModelo;
    @FXML
    private TableColumn<Modelo, String> tcMarca;
    @FXML
    private TableColumn<Modelo, String> tcCategoria;
    
    private List<Modelo> listModelos;
    private ObservableList<Modelo> obsListModelos;
    
    private List<Marca> listMarcas;
    private ObservableList<Marca> obsListMarcas;
    
    private List<Categoria> listCategorias;
    private ObservableList<Categoria> obsListCategorias;

    Modelo modelo;
        // = new Modelo();
    
    ModeloDAO modeloDAO = 
        new ModeloDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    MarcaDAO marcaDAO = 
        new MarcaDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    CategoriaDAO categoriaDAO = 
        new CategoriaDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    
@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarComboBoxMarca();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneModelosController.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         try {
            carregarComboBoxCategoria();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneModelosController.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        try {
            carregarTabelaModelos();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneModelosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaModelos.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaModelo(newValue));
        
    }

    public void carregarComboBoxMarca() throws DAOException {
        listMarcas = marcaDAO.getAll();
        obsListMarcas = FXCollections.observableArrayList(listMarcas);
        cbMarca.setItems(obsListMarcas);
    }    
    
    public void carregarComboBoxCategoria() throws DAOException {
        listCategorias = categoriaDAO.getAll();
        obsListCategorias = FXCollections.observableArrayList(listCategorias);
        cbCategoria.setItems(obsListCategorias);
    } 
     
    public void carregarTabelaModelos() throws DAOException {
        tcIdModelo.setCellValueFactory(new PropertyValueFactory("id"));
        tcDescricaoModelo.setCellValueFactory(new PropertyValueFactory("descricao"));
        //tcMarca.setCellValueFactory(new PropertyValueFactory("marca_id"));
        tcMarca.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getMarcaId().getNome()));
        tcCategoria.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getCategoriaId().getNome()));
                
        listModelos = modeloDAO.getAll();
        
        obsListModelos = FXCollections.observableArrayList(listModelos);
        tabelaModelos.setItems(obsListModelos);
        tabelaModelos.refresh();
    }
    
    public void selecionarItemTabelaModelo(Modelo modelo) {
        if (modelo != null){
            labelIdModelo.setText(String.valueOf(modelo.getId()));
            tfDescricaoModelo.setText(String.valueOf(modelo.getDescricao()));
            cbMarca.setValue(modelo.getMarcaId());
            cbCategoria.setValue(modelo.getCategoriaId());        
        }
        else {
            limparCampos();
        }
    }
    // implementar metodos
    // como carregar tabela com marca e categoria
    @FXML
    public void handleBtInserirModelo() throws IOException, DAOException {
        if (tfDescricaoModelo.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Modelo modelo = new Modelo();
            modelo.setDescricao(tfDescricaoModelo.getText());
            modelo.setMarcaId((Marca) cbMarca.getSelectionModel().getSelectedItem());
            modelo.setCategoriaId((Categoria) cbCategoria.getSelectionModel().getSelectedItem());
            modeloDAO.salvar(modelo);
            carregarTabelaModelos();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarModelo() throws IOException, DAOException {
        Modelo modelo = tabelaModelos.getSelectionModel().getSelectedItem();
        if (modelo != null){
            modelo.setDescricao(tfDescricaoModelo.getText());
            modelo.setMarcaId((Marca) cbMarca.getSelectionModel().getSelectedItem());
            modelo.setCategoriaId((Categoria) cbCategoria.getSelectionModel().getSelectedItem());
            modeloDAO.alterar(modelo);
            carregarTabelaModelos(); 
            limparCampos();
            }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um modelo.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverModelo() throws IOException, DAOException {
        Modelo modelo = tabelaModelos.getSelectionModel().getSelectedItem();
        if (modelo != null) {
            modeloDAO.excluir(modelo.getId());
            carregarTabelaModelos();
            limparCampos();
            // usando o método excluir com parametro modelo nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um modelo.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        modelo = null;
        labelIdModelo.setText("");
        tfDescricaoModelo.setText("");
        cbMarca.getSelectionModel().select(null);
        cbCategoria.getSelectionModel().select(null);
    }
}
