/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.OrdemServicoDAO;
import dao.ServicoDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.persistence.Persistence;
import model.ItemOS;
import model.ItemOSPK;
import model.OrdemServico;
import model.Servico;
import model.Veiculo;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneOrdemServicoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private AnchorPane apOrdemServico;
    @FXML
    private RadioButton rbAberta;
    @FXML
    private RadioButton rbFechada;
    @FXML
    private Label lbNumero;
    @FXML
    private DatePicker dpAgenda;
    @FXML
    private TextField tfHorario;
    @FXML
    private TextField tfVeiculo;
    @FXML
    private Button btBuscarVeiculo;
    @FXML
    private Button btNovoVeiculo;
    @FXML
    private TextField tfModelo;
    @FXML
    private TextField tfMarca;
    @FXML
    private TextField tfCategoria;
    @FXML
    private TextField tfCliente;
    @FXML
    private Label lbValorTotal;
    @FXML
    private Button btSalvarOS;
    @FXML
    private Button btCancelar;
    
    @FXML
    private ComboBox cbServico;
    @FXML
    private Label lbValorServico;    
    @FXML
    private Button btInserirItem;
    @FXML
    private Button btRemoverItem;
    @FXML
    private TableView<ItemOS> tabelaItensOrdem;
    @FXML
    private TableColumn<ItemOS, String> tcVeiculo;
    @FXML
    private TableColumn<ItemOS, String> tcServico;
    @FXML
    private TableColumn<ItemOS, String> tcValor;
    
    private List<ItemOS> listItensOs;
    private ObservableList<ItemOS> obsListItensOs;
    
    private List<Servico> listServicos;
    private ObservableList<Servico> obsListServicos;
    
    Veiculo veiculo = new Veiculo();
    ItemOS itemOs;
    OrdemServico os;
    private boolean novo;
    //public static double total;
    
    ServicoDAO servicoDAO
            = new ServicoDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    OrdemServicoDAO osDAO
            = new OrdemServicoDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        os = new OrdemServico();
        novo = true;
        try {
            lbNumero.setText(osDAO.getNovoNumeroOS().toString());
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneOrdemServicoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            carregarComboBoxServicos();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneOrdemServicoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            carregarTabelaItensOs();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneOrdemServicoController.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Listen acionado quando selecionado os itens do table view
        tabelaItensOrdem.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaItensOrdem(newValue));
        
    }
    
    public void carregarComboBoxServicos() throws DAOException {
        listServicos = servicoDAO.getAll();
        obsListServicos = FXCollections.observableArrayList(listServicos);
        cbServico.setItems(obsListServicos);
    }    
    
    public void carregarTabelaItensOs() throws DAOException {
        //PODE TER PROBLEMA AQUI
        tcVeiculo.setCellValueFactory((param)
                -> new SimpleStringProperty(param.getValue().getOrdemServico().getVeiculoId().getPlaca()));
        tcServico.setCellValueFactory((param)
                -> new SimpleStringProperty(param.getValue().getServico().getDescricao()));
        tcValor.setCellValueFactory((param)
                -> new SimpleStringProperty(param.getValue().getValorServico().toString()));
        
        obsListItensOs = FXCollections.observableArrayList(os.getItemOSCollection());
        tabelaItensOrdem.setItems(obsListItensOs);
        tabelaItensOrdem.refresh();
    }
    
    public void selecionarItemTabelaItensOrdem(ItemOS itemOs) {
        if (itemOs != null) {
            // item
            cbServico.setValue(itemOs.getServico());
            lbValorServico.setText(String.valueOf(itemOs.getValorServico()));
        } else {
            limparServico();
        }
    }

    // AÇÕES DE BOTAO
    @FXML
    public void handleBtSalvarOS() throws IOException, DAOException, ParseException {
        
        if (tfVeiculo.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        } else {
            Calendar gc = new GregorianCalendar(dpAgenda.getValue().getYear(), dpAgenda.getValue().getMonthValue(), dpAgenda.getValue().getDayOfMonth());
            os.setAgenda(new Date(gc.getTimeInMillis()));
            //System.out.println("Testando: " + os.getAgenda());
            
            SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm"); 
            Date horario = formatoHora.parse(tfHorario.getText());
            //System.out.println("Testando: " + formatoHora.format(horario));
            os.setHorario(horario);
            //System.out.println("Testando: " + os.getHorario());

            if (rbAberta.isSelected()) {
                os.setStatus(true);
            } else {
                os.setStatus(false);
            }
            
            osDAO.salvar(os);
            limparCampos();
            limparServico();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Ordem de serviço registrada com sucesso.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtCancelar() throws IOException {
        this.anchorPane.setVisible(false);
    }
    
    @FXML
    public void handleBtBuscarVeiculo() throws IOException, DAOException {
        showFXMLAnchorPaneBuscarVeiculoController(veiculo);
    }
    
    @FXML
    public void handleMenuItemCadastrarVeiculo() throws IOException {
        AnchorPane a = (AnchorPane) FXMLLoader.load(getClass().getResource("/view/FXMLAnchorPaneVeiculos.fxml"));
        anchorPane.getChildren().setAll(a);
    }
    
    @FXML
    public void handleBtInserirItem() throws IOException, DAOException {
//        adicionar item a collection
        
        if (cbServico.getSelectionModel() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, selecione um serviço.");
            alert.show();
        }
        else {
            itemOs = new ItemOS();
            itemOs.setOrdemServico(os);
            //Marcos Pisching: Adicionei a linha a seguir para obter o um novo número de OS e o usei entendendo ser o próximo número da OS a ser utilizada como chave primária dos itens da OS
            int numeroOS = 0; 
            try {
                numeroOS = osDAO.getNovoNumeroOS();
            } catch (DAOException ex) {
                numeroOS = 1;
            }

            Servico servico = (Servico) cbServico.getSelectionModel().getSelectedItem();
            itemOs.setServico(servico);
            defineValorServico(itemOs);
            ItemOSPK itempk = new ItemOSPK(numeroOS, servico.getId());
            servico.getItemOSCollection().add(itemOs);
            itemOs.setItemOSPK(itempk);
            
            os.getItemOSCollection().add(itemOs);
                    
            carregarTabelaItensOs();
            this.setTotal();
            limparServico();
        }
    }
    
    @FXML
    public void handleBtRemoverItem() throws IOException, DAOException {
//        remover item da collection
        if (itemOs.getServico() != null) {
            os.getItemOSCollection().remove(itemOs);
            carregarTabelaItensOs();
            this.setTotal();
            limparServico();
        }
         else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um serviço.");
            alert.show();
        }
    }
    
    public void limparCampos() throws DAOException {
        try {
            lbNumero.setText(osDAO.getNovoNumeroOS().toString());
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneOrdemServicoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        rbAberta.setSelected(false);
        rbFechada.setSelected(false);
        dpAgenda.getEditor().clear();
        tfHorario.setText("");
        tfVeiculo.setText("");
        lbValorTotal.setText("");
        tfVeiculo.setText("");
        tfModelo.setText("");
        tfMarca.setText("");
        tfCategoria.setText("");
        tfCliente.setText("");
        os = new OrdemServico();
        novo = true;
        carregarTabelaItensOs();
    }
    public void limparServico() {
        cbServico.getSelectionModel().select(null);
        lbValorServico.setText("");
    }
    
    public void showFXMLAnchorPaneBuscarVeiculoController(Veiculo veiculo) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLAnchorPaneBuscarVeiculoController.class.getResource("/view/FXMLAnchorPaneBuscarVeiculo.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // stage dialog
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Buscar Veículo");
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);
        
        FXMLAnchorPaneBuscarVeiculoController controller = loader.getController();
        controller.setDialogStage(dialogStage);
        
        dialogStage.showAndWait();
        
        this.veiculo = FXMLAnchorPaneBuscarVeiculoController.veiculoTemp;
        FXMLAnchorPaneBuscarVeiculoController.veiculoTemp = null;
        preencherVeiculo(this.veiculo);
        os.setVeiculoId(this.veiculo);
    }
    
    
    public void preencherVeiculo(Veiculo veiculo) {
        tfVeiculo.setText(veiculo.getPlaca());
        tfModelo.setText(veiculo.getModeloId().toString());
        tfMarca.setText(veiculo.getModeloId().getMarcaId().toString());
        tfCategoria.setText(veiculo.getModeloId().getCategoriaId().toString());
        tfCliente.setText(veiculo.getClienteId().toString());
    }
    
    public void defineValorServico(ItemOS itemOs) {
        double desconto = itemOs.getOrdemServico().getVeiculoId().getModeloId().getCategoriaId().getTaxaDesconto();
        double valor = itemOs.getServico().getValor();
        itemOs.setValorServico(valor - (valor * desconto));
    }
    
    @FXML
    public void setTotal() {
        double total = 0;
        if (os.getItemOSCollection().isEmpty()) {
            lbValorTotal.setText("0,00");    
        }
        else {
            for (ItemOS i : os.getItemOSCollection()) {
                total += i.getValorServico();
            }
            lbValorTotal.setText(Double.toString(total));
        }
    }
    
    @FXML
    public void preencheValorServico() {
        if (veiculo == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um veiculo.");
            alert.show();
        }
        else {
            if (cbServico.getSelectionModel().getSelectedIndex() >= 0) {
                double desconto = this.veiculo.getModeloId().getCategoriaId().getTaxaDesconto();
                double valor = ((Servico) cbServico.getSelectionModel().getSelectedItem()).getValor();
                double valorServico = valor - (valor * desconto);
                lbValorServico.setText(String.valueOf(valorServico));
            }
        }
        
    }
}
