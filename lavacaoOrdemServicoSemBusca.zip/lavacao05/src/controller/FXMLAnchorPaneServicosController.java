/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ServicoDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Servico;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneServicosController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroServico;
    @FXML
    private TextField tfValorServico;
    @FXML
    private TextArea tfDescricaoServico;
    @FXML
    private Label labelIdServico;
    @FXML
    private Button btInserirServico;
    @FXML
    private Button btAlterarServico;
    @FXML
    private Button btRemoverServico;
    @FXML
    private TableView<Servico> tabelaServicos;
    @FXML
    private TableColumn<Servico, String> tcServicoId;
    @FXML
    private TableColumn<Servico, String> tcServicoValor;
    @FXML
    private TableColumn<Servico, String> tcServicoDescricao;
    
    private List<Servico> listServicos;
    private ObservableList<Servico> obsListServicos;

    Servico servico;
        // = new Servico();
    
    ServicoDAO servicoDAO = 
        new ServicoDAO(Persistence.createEntityManagerFactory("lavacao05PU"));

@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarTabelaServicos();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneServicosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaServicos.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaServico(newValue));
        
    }    
     
    public void carregarTabelaServicos() throws DAOException {
        tcServicoId.setCellValueFactory(new PropertyValueFactory("id"));
        tcServicoValor.setCellValueFactory(new PropertyValueFactory("valor"));
        tcServicoDescricao.setCellValueFactory(new PropertyValueFactory("descricao"));
                
        listServicos = servicoDAO.getAll();
        
        obsListServicos = FXCollections.observableArrayList(listServicos);
        tabelaServicos.setItems(obsListServicos);
        tabelaServicos.refresh();

    }
    
    public void selecionarItemTabelaServico(Servico servico) {
        if (servico != null){
            labelIdServico.setText(String.valueOf(servico.getId()));
            tfValorServico.setText(String.valueOf(servico.getValor()));
            tfDescricaoServico.setText(String.valueOf(servico.getDescricao()));
        }
        else {
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtInserirServico() throws IOException, DAOException {
        if (tfValorServico.getText().equals("") || tfDescricaoServico.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Servico servico = new Servico();
            servico.setValor(Double.parseDouble(tfValorServico.getText()));
            servico.setDescricao(tfDescricaoServico.getText());
            servicoDAO.salvar(servico);
            carregarTabelaServicos();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarServico() throws IOException, DAOException {
        Servico servico = tabelaServicos.getSelectionModel().getSelectedItem();
        if (servico != null){
            servico.setValor(Double.parseDouble(tfValorServico.getText()));
            servico.setDescricao(tfDescricaoServico.getText());
        servicoDAO.alterar(servico);
        carregarTabelaServicos(); 
        limparCampos();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um servico.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverServico() throws IOException, DAOException {
        Servico servico = tabelaServicos.getSelectionModel().getSelectedItem();
        if (servico != null) {
            servicoDAO.excluir(servico.getId());
            carregarTabelaServicos();
            limparCampos();
            // usando o método excluir com parametro servico nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um servico.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        servico = null;
        labelIdServico.setText("");
        tfValorServico.setText("");
        tfDescricaoServico.setText("");
    }
}
