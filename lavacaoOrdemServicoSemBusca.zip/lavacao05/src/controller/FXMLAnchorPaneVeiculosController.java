/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ClienteDAO;
import dao.CorDAO;
import dao.MarcaDAO;
import dao.ModeloDAO;
import dao.VeiculoDAO;
import exceptions.DAOException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.persistence.Persistence;
import model.Cliente;
import model.Cor;
import model.Marca;
import model.Modelo;
import model.Veiculo;

/**
 * FXML Controller class
 *
 * @author agatha
 */
public class FXMLAnchorPaneVeiculosController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane apCadastroVeiculo;
    @FXML
    private TextField tfPlaca;
    @FXML
    private ComboBox cbCor;
    @FXML
    private ComboBox cbProprietario;
    @FXML
    private ComboBox cbMarca;
    @FXML
    private ComboBox cbModelo;
    @FXML
    private Label labelIdVeiculo;
    @FXML
    private Button btInserirVeiculo;
    @FXML
    private Button btAlterarVeiculo;
    @FXML
    private Button btRemoverVeiculo;
    @FXML
    private TableView<Veiculo> tabelaVeiculos;
    @FXML
    private TableColumn<Veiculo, String> tcIdVeiculo;
    @FXML
    private TableColumn<Veiculo, String> tcPlaca;
    @FXML
    private TableColumn<Veiculo, String> tcModelo;
    @FXML
    private TableColumn<Veiculo, String> tcProprietario;
    
    private List<Veiculo> listVeiculos;
    private ObservableList<Veiculo> obsListVeiculos;
    
    private List<Cor> listCores;
    private ObservableList<Cor> obsListCores;
    
    private List<Cliente> listProprietarios;
    private ObservableList<Cliente> obsListProprietarios;
    
    private List<Marca> listMarcas;
    private ObservableList<Marca> obsListMarcas;
    
    private List<Modelo> listModelos;
    private ObservableList<Modelo> obsListModelos;

    Veiculo veiculo;
        // = new Veiculo();
    
    VeiculoDAO veiculoDAO = 
        new VeiculoDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    MarcaDAO marcaDAO = 
        new MarcaDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    CorDAO corDAO = 
        new CorDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    ClienteDAO clienteDAO = 
        new ClienteDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    ModeloDAO modeloDAO = 
        new ModeloDAO(Persistence.createEntityManagerFactory("lavacao05PU"));
    
@Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            carregarComboBoxCor();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneVeiculosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            carregarComboBoxProprietario();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneVeiculosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            carregarComboBoxMarca();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneVeiculosController.class.getName()).log(Level.SEVERE, null, ex);
        }
         try {
            carregarComboBoxModelo();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneVeiculosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            carregarTabelaVeiculos();
        } catch (DAOException ex) {
            Logger.getLogger(FXMLAnchorPaneVeiculosController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Listen acionado quando selecionado os itens do table view
        tabelaVeiculos.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> selecionarItemTabelaVeiculo(newValue));
        
    }

    public void carregarComboBoxCor() throws DAOException {
        listCores = corDAO.getAll();
        obsListCores = FXCollections.observableArrayList(listCores);
        cbCor.setItems(obsListCores);
    } 
    public void carregarComboBoxProprietario() throws DAOException {
        listProprietarios = clienteDAO.getAll();
        obsListProprietarios = FXCollections.observableArrayList(listProprietarios);
        cbProprietario.setItems(obsListProprietarios);
    } 
    public void carregarComboBoxMarca() throws DAOException {
        listMarcas = marcaDAO.getAll();
        obsListMarcas = FXCollections.observableArrayList(listMarcas);
        cbMarca.setItems(obsListMarcas);
    }    
    
    @FXML
    public void carregarComboBoxModelo() throws DAOException {
        if (cbMarca.getSelectionModel().getSelectedItem() == null) {
            cbModelo.getSelectionModel().select(null);
        }
        else {
            //listModelos = ((Marca) cbMarca.getSelectionModel().getSelectedItem()).getModeloCollection();
            obsListModelos = FXCollections.observableArrayList(((Marca) cbMarca.getSelectionModel().getSelectedItem()).getModeloCollection());
            cbModelo.setItems(obsListModelos);
        }
    } 
     
    public void carregarTabelaVeiculos() throws DAOException {
        tcIdVeiculo.setCellValueFactory(new PropertyValueFactory("id"));
        tcPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
        tcModelo.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getModeloId().getDescricao()));
        tcProprietario.setCellValueFactory((param) -> 
        new SimpleStringProperty(param.getValue().getClienteId().getNome()));
                
        listVeiculos = veiculoDAO.getAll();
        
        obsListVeiculos = FXCollections.observableArrayList(listVeiculos);
        tabelaVeiculos.setItems(obsListVeiculos);
        tabelaVeiculos.refresh();
    }
    
    public void selecionarItemTabelaVeiculo(Veiculo veiculo) {
        if (veiculo != null){
            labelIdVeiculo.setText(String.valueOf(veiculo.getId()));
            tfPlaca.setText(String.valueOf(veiculo.getPlaca()));
            cbCor.setValue(veiculo.getCorId());
            cbProprietario.setValue(veiculo.getClienteId());
            cbMarca.setValue(veiculo.getModeloId().getMarcaId());
            cbModelo.setValue(veiculo.getModeloId());        
        }
        else {
            limparCampos();
        }
    }
    // implementar metodos
    // como carregar tabela com marca e categoria
    @FXML
    public void handleBtInserirVeiculo() throws IOException, DAOException {
        if (tfPlaca.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, preencha os campos.");
            alert.show();
        }
        else {
            Veiculo veiculo = new Veiculo();
            veiculo.setPlaca(tfPlaca.getText());
            veiculo.setCorId((Cor) cbCor.getSelectionModel().getSelectedItem());
            veiculo.setClienteId((Cliente) cbProprietario.getSelectionModel().getSelectedItem());
            veiculo.setModeloId((Modelo) cbModelo.getSelectionModel().getSelectedItem());
            
            veiculoDAO.salvar(veiculo);
            carregarTabelaVeiculos();
            limparCampos();
        }
    }
    
    @FXML
    public void handleBtAlterarVeiculo() throws IOException, DAOException {
        Veiculo veiculo = tabelaVeiculos.getSelectionModel().getSelectedItem();
        if (veiculo != null){
            veiculo.setPlaca(tfPlaca.getText());
            veiculo.setCorId((Cor) cbCor.getSelectionModel().getSelectedItem());
            veiculo.setClienteId((Cliente) cbProprietario.getSelectionModel().getSelectedItem());
            veiculo.setModeloId((Modelo) cbModelo.getSelectionModel().getSelectedItem());
            veiculoDAO.alterar(veiculo);
            carregarTabelaVeiculos(); 
            limparCampos();
            }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um veiculo.");
            alert.show();
        }
    }
    
    @FXML
    public void handleBtRemoverVeiculo() throws IOException, DAOException {
        Veiculo veiculo = tabelaVeiculos.getSelectionModel().getSelectedItem();
        if (veiculo != null) {
            veiculoDAO.excluir(veiculo.getId());
            carregarTabelaVeiculos();
            limparCampos();
            // usando o método excluir com parametro veiculo nao funciona
            // dá null pointer exception, pq?
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Por favor, escolha um veiculo.");
            alert.show();
        }
    }
    
    public void limparCampos() {
        veiculo = null;
        labelIdVeiculo.setText("");
        tfPlaca.setText("");
        cbCor.getSelectionModel().select(null);
        cbProprietario.getSelectionModel().select(null);
        cbMarca.getSelectionModel().select(null);
        cbModelo.getSelectionModel().select(null);
    }
}
