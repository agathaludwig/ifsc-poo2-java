/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import model.Categoria;

/**
 *
 * @author agatha
 */
public class CategoriaDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public CategoriaDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Categoria categoria) throws DAOException {
        validarCampos(categoria);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(categoria);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possvíel armazenar a categoria no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return categoria.getId();
    }
    
    public void alterar(Categoria categoria) throws DAOException {
        validarCampos(categoria);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            categoria = em.merge(categoria);
            
            em.getTransaction().commit();
            em.refresh(categoria);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Categoria categoria) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(categoria);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta categoria. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta categoria.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the categoria that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Categoria categoria = em.find(Categoria.class, id);
            //set the ususario to be deleted
            em.remove(categoria);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta categoria. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta categoria.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Categoria getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Categoria categoria = eManager.find(Categoria.class, id);
            return categoria;
        }finally{
            eManager.close();
        }
    }
    
    public Categoria getByNome(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Categoria.findByNome");
            query.setParameter("nome", str);
            return (Categoria) query.getSingleResult();
        }finally{
            em.close();
        }
    }
    
    public List<Categoria> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Categoria> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Categoria.findAll");
            em.getTransaction().commit();
            lista = (List<Categoria>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Categoria categoria) throws DAOException {
        if (categoria.getNome() == null || categoria.getNome().trim().equals("")) {
            throw new DAOException("[Nome da categoria: Campo obrigatório] Informe o nome da categoria");
        } 
        
    }
   
}
