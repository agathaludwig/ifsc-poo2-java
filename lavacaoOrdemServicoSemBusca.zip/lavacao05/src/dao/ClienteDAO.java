/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import model.Cliente;
import model.PessoaFisica;
import model.PessoaJuridica;

/**
 *
 * @author agatha
 */
public class ClienteDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public ClienteDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Cliente cliente) throws DAOException {
        validarCampos(cliente);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(cliente);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possível armazenar o cliente no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return cliente.getId();
    }
    
    public void alterar(Cliente cliente) throws DAOException {
        validarCampos(cliente);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            cliente = em.merge(cliente);
            
            em.getTransaction().commit();
            em.refresh(cliente);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Cliente cliente) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este cliente. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este cliente.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the cliente that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Cliente cliente = em.find(Cliente.class, id);
            //set the ususario to be deleted
            em.remove(cliente);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este cliente. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este cliente.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Cliente getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Cliente cliente = eManager.find(Cliente.class, id);
            return cliente;
        }finally{
            eManager.close();
        }
    }
    
    public Cliente getByNome(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Cliente.findByNome");
            query.setParameter("nome", str);
            return (Cliente) query.getSingleResult();
        }finally{
            em.close();
        }
    }
    
    public List<Cliente> getByNearNome(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Cliente> lista;
        try{
            Query query = em.createNamedQuery("Cliente.findByNearNome");
            query.setParameter("nome", str + "%");
            em.getTransaction().commit();
            lista = (List<Cliente>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        return lista;
    }
    
    public List<Cliente> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Cliente> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Cliente.findAll");
            em.getTransaction().commit();
            lista = (List<Cliente>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Cliente cliente) throws DAOException {
        if (cliente.getNome() == null || cliente.getNome().trim().equals("")) {
            throw new DAOException("[Nome do cliente: Campo obrigatório] Informe o nome do cliente");
        } 
        if (cliente instanceof PessoaFisica) {
            if (((PessoaFisica) cliente).getCpf() == null || ((PessoaFisica) cliente).getCpf().length() == 0 ) {
                throw new DAOException("[CPF do cliente: Campo obrigatório] Informe o cpf do cliente");
            }
        }
        if (cliente instanceof PessoaJuridica) {
            if (((PessoaJuridica) cliente).getCnpj() == null || ((PessoaJuridica) cliente).getCnpj().length() == 0 ) {
                throw new DAOException("[CNPJ do cliente: Campo obrigatório] Informe o CNPJ do cliente");
            }
        }
    }
   
}
