/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import model.Cor;

/**
 *
 * @author agatha
 */
public class CorDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public CorDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Cor cor) throws DAOException {
        validarCampos(cor);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(cor);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possível armazenar a cor no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return cor.getId();
    }
    
    public void alterar(Cor cor) throws DAOException {
        validarCampos(cor);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            cor = em.merge(cor);
            
            em.getTransaction().commit();
            em.refresh(cor);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Cor cor) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(cor);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta cor. \nEla possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta cor.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the cor that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Cor cor = em.find(Cor.class, id);
            //set the ususario to be deleted
            em.remove(cor);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta cor. \nEla possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta cor.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Cor getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Cor cor = eManager.find(Cor.class, id);
            return cor;
        }finally{
            eManager.close();
        }
    }
    
    public Cor getByCor(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Cor.findByCor");
            query.setParameter("cor", str);
            return (Cor) query.getSingleResult();
        }finally{
            em.close();
        }
    }
    
    public List<Cor> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Cor> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Cor.findAll");
            em.getTransaction().commit();
            lista = (List<Cor>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Cor cor) throws DAOException {
        if (cor.getCor() == null || cor.getCor().trim().equals("")) {
            throw new DAOException("[Nome do cor: Campo obrigatório] Informe o nome da cor");
        } 
        
    }
   
}
