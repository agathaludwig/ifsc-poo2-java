/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import model.Marca;

/**
 *
 * @author agatha
 */
public class MarcaDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public MarcaDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Marca marca) throws DAOException {
        validarCampos(marca);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(marca);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possível armazenar a marca no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return marca.getId();
    }
    
    public void alterar(Marca marca) throws DAOException {
        validarCampos(marca);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            marca = em.merge(marca);
            
            em.getTransaction().commit();
            em.refresh(marca);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Marca marca) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(marca);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta marca. \nEla possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta marca.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the marca that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Marca marca = em.find(Marca.class, id);
            //set the ususario to be deleted
            em.remove(marca);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta marca. \nEla possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta marca.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Marca getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Marca marca = eManager.find(Marca.class, id);
            return marca;
        }finally{
            eManager.close();
        }
    }
    
    public Marca getByNome(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Marca.findByNome");
            query.setParameter("nome", str);
            return (Marca) query.getSingleResult();
        }finally{
            em.close();
        }
    }
    
    public List<Marca> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Marca> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Marca.findAll");
            em.getTransaction().commit();
            lista = (List<Marca>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Marca marca) throws DAOException {
        if (marca.getNome() == null || marca.getNome().trim().equals("")) {
            throw new DAOException("[Nome do marca: Campo obrigatório] Informe o nome da marca");
        } 
        
    }
   
}
