/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import model.Marca;
import model.Modelo;

/**
 *
 * @author agatha
 */
public class ModeloDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public ModeloDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Modelo modelo) throws DAOException {
        validarCampos(modelo);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(modelo);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possvíel armazenar o modelo no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return modelo.getId();
    }
    
    public void alterar(Modelo modelo) throws DAOException {
        validarCampos(modelo);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            modelo = em.merge(modelo);
            
            em.getTransaction().commit();
            em.refresh(modelo);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Modelo modelo) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(modelo);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este modelo. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este modelo.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the modelo that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Modelo modelo = em.find(Modelo.class, id);
            //set the ususario to be deleted
            em.remove(modelo);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este modelo. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este modelo.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Modelo getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Modelo modelo = eManager.find(Modelo.class, id);
            return modelo;
        }finally{
            eManager.close();
        }
    }
    
    public Modelo getByDescricao(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Modelo.findByDescricao");
            query.setParameter("descricao", str);
            return (Modelo) query.getSingleResult();
        }finally{
            em.close();
        }
    }
       
    public List<Modelo> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Modelo> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Modelo.findAll");
            em.getTransaction().commit();
            lista = (List<Modelo>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Modelo modelo) throws DAOException {
        if (modelo.getDescricao() == null || modelo.getDescricao().trim().equals("")) {
            throw new DAOException("[Descricao do modelo: Campo obrigatório] Informe a descrição do modelo");
        } 
        
    }
   
}
