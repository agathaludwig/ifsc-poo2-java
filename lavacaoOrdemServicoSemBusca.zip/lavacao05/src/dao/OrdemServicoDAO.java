/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import model.ItemOS;
import model.ItemOSPK;
import model.OrdemServico;

/**
 *
 * @author agatha
 */
public class OrdemServicoDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public OrdemServicoDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(OrdemServico ordemservico) throws DAOException {
        validarCampos(ordemservico);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(ordemservico);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possível armazenar a OS no banco de dados",
                e.getCause());
        }finally{
            eManager.close();
        }
        return ordemservico.getNumero();
    }
    
    public Integer getNovoNumeroOS() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        OrdemServico os = null;
        int numeroOS = 0;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("OrdemServico.getUltimoNumero").setMaxResults(1);
            em.getTransaction().commit();
            os = (OrdemServico) query.getSingleResult();
            if (os != null) {
                numeroOS = os.getNumero() + 1;
            }
        } catch (Exception e) {
//            em.getTransaction().rollback();
            throw new DAOException(e);
        }finally{
            em.close();
        }
        return numeroOS;
    }
    
    public void alterar(OrdemServico ordemservico) throws DAOException {
        validarCampos(ordemservico);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            ordemservico = em.merge(ordemservico);
            
            em.getTransaction().commit();
            em.refresh(ordemservico);
        }finally{
            em.close();
        }
    }
   
    public void excluir(OrdemServico ordemservico) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(ordemservico);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta ordem de servico. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta ordem de servico.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer numero) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the ordemservico that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            OrdemServico ordemservico = em.find(OrdemServico.class, numero);
            //set the ususario to be deleted
            em.remove(ordemservico);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir esta ordem de servico. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir esta ordem de servico.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public OrdemServico getByNumero(Integer numero) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            OrdemServico ordemservico = eManager.find(OrdemServico.class, numero);
            return ordemservico;
        }finally{
            eManager.close();
        }
    }
    
    public OrdemServico getByAgenda(Date data) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("OrdemServico.findByAgenda");
            //transformar formato de data?
            query.setParameter("agenda", data);
            return (OrdemServico) query.getSingleResult();
        }finally{
            em.close();
        }
    }
        
    public List<OrdemServico> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<OrdemServico> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("OrdemServico.findAll");
            em.getTransaction().commit();
            lista = (List<OrdemServico>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(OrdemServico ordemservico) throws DAOException {
        if (ordemservico.getVeiculoId() == null) {
            throw new DAOException("[Veículo da OS: Campo obrigatório] Informe a placa do veículo");
        } 
        if (ordemservico.getAgenda() == null) {
            throw new DAOException("[Data da OS: Campo obrigatório] Informe a data da OS");
        } 
        if (ordemservico.getHorario() == null) {
            throw new DAOException("[Horário da OS: Campo obrigatório] Informe a hora da OS");
        } 
//        if (ordemservico.getItemOSCollection() == null || ordemservico.getItemOSCollection().isEmpty()) {
//            throw new DAOException("[Serviços da OS: Campo obrigatório] Informe os serviços da OS");
//        } 
        
        
    }
   
}
