/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import model.Servico;

/**
 *
 * @author agatha
 */
public class ServicoDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public ServicoDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Servico servico) throws DAOException {
        validarCampos(servico);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(servico);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possvíel armazenar o servico no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return servico.getId();
    }
    
    public void alterar(Servico servico) throws DAOException {
        validarCampos(servico);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            servico = em.merge(servico);
            
            em.getTransaction().commit();
            em.refresh(servico);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Servico servico) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(servico);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este servico. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este servico.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the servico that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Servico servico = em.find(Servico.class, id);
            //set the ususario to be deleted
            em.remove(servico);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este servico. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este servico.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Servico getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Servico servico = eManager.find(Servico.class, id);
            return servico;
        }finally{
            eManager.close();
        }
    }
    
    public Servico getByDescricao(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Servico.findByDescricao");
            query.setParameter("descricao", str);
            return (Servico) query.getSingleResult();
        }finally{
            em.close();
        }
    }
    
    public List<Servico> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Servico> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Servico.findAll");
            em.getTransaction().commit();
            lista = (List<Servico>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Servico servico) throws DAOException {
        if (servico.getDescricao() == null || servico.getDescricao().trim().equals("")) {
            throw new DAOException("[Descricao do servico: Campo obrigatório] Informe a descrição do servico");
        } 
        
    }
   
}
