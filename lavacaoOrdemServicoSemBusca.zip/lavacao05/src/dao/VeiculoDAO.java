/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//lembrar de configurar as excecoes dos ultimos metodos
package dao;

import exceptions.DAOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import model.Veiculo;

/**
 *
 * @author agatha
 */
public class VeiculoDAO {
    private EntityManagerFactory emf;
    private EntityManager em = null;
    
    public VeiculoDAO(EntityManagerFactory emf) {
        this.setEmf(emf);
    }
    
    public EntityManagerFactory getEmf() {
        return emf;
    }
    
    public void setEmf(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    
    public void setEntityManager(EntityManager em) {
        this.em = em;
    }
    
    public Integer salvar(Veiculo veiculo) throws DAOException {
        validarCampos(veiculo);
        
        EntityManager eManager = getEmf().createEntityManager();
        try{
            eManager.getTransaction().begin();
            eManager.persist(veiculo);
            eManager.getTransaction().commit();
        } catch (Exception e) {
            eManager.getTransaction().rollback();
            throw new DAOException("Não foi possvíel armazenar o veiculo no banco de dados",
                    e.getCause());
        }finally{
            eManager.close();
        }
        return veiculo.getId();
    }
    
    public void alterar(Veiculo veiculo) throws DAOException {
        validarCampos(veiculo);
        
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            veiculo = em.merge(veiculo);
            
            em.getTransaction().commit();
            em.refresh(veiculo);
        }finally{
            em.close();
        }
    }
   
    public void excluir(Veiculo veiculo) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            em.getTransaction().begin();
            em.remove(veiculo);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este veiculo. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este veiculo.",  e.getCause());
            }
        }finally{
            em.close();
        }        
    }
    
    public void excluir(Integer id) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            //changes will be made so begin a transaction
            em.getTransaction().begin();
            //find the veiculo that will be deleted.  This step ensures the order
            //will be managed as the specification requires the object be
            //managed before remove can be called.
            Veiculo veiculo = em.find(Veiculo.class, id);
            //set the ususario to be deleted
            em.remove(veiculo);
            //commit the transaction, this will cause the the delete SQL to be
            //sent to the database.
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause().getClass().getName().equals("org.hibernate.exception.ConstraintViolationException")) {
                throw new DAOException("Não é possível excluir este veiculo. \nEle possui vínculo com outros cadastros.");
            }
            else {
                throw new DAOException("Não foi possível excluir este veiculo.",  e.getCause());
            }
            
        }finally{
            em.close();
        }
        
    }
    
    public Veiculo getById(Integer id) throws DAOException {
        EntityManager eManager = getEmf().createEntityManager();
        try{
            Veiculo veiculo = eManager.find(Veiculo.class, id);
            return veiculo;
        }finally{
            eManager.close();
        }
    }
    
    public Veiculo getByPlaca(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        try{
            Query query = em.createNamedQuery("Veiculo.findByPlaca");
            query.setParameter("placa", str);
            return (Veiculo) query.getSingleResult();
        }finally{
            em.close();
        }
    }
        public List<Veiculo> getByNearPlaca(String str) throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Veiculo> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Veiculo.findByNearPlaca");
            query.setParameter("placa", "%" + str + "%");
            em.getTransaction().commit();
            lista = (List<Veiculo>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    public List<Veiculo> getAll() throws DAOException {
        EntityManager em = getEmf().createEntityManager();
        List<Veiculo> lista;
        try{
            em.getTransaction().begin();
            Query query = em.createNamedQuery("Veiculo.findAll");
            em.getTransaction().commit();
            lista = (List<Veiculo>) query.getResultList();
        } catch (Exception e) {
            em.getTransaction().rollback();
            lista = null;
        }finally{
            em.close();
        }
        
        return lista;
    }
    
    // campos obrigatorios
    private void validarCampos(Veiculo veiculo) throws DAOException {
        if (veiculo.getPlaca() == null || veiculo.getPlaca().trim().equals("")) {
            throw new DAOException("[Placa do veiculo: Campo obrigatório] Informe a placa do veiculo");
        } 
        
    }
   
}
