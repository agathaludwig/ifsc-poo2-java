/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author agatha
 */
@Entity
@Table(name = "itemOS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ItemOS.findAll", query = "SELECT i FROM ItemOS i")
    , @NamedQuery(name = "ItemOS.findByNumero", query = "SELECT i FROM ItemOS i WHERE i.itemOSPK.numero = :numero")
    , @NamedQuery(name = "ItemOS.findByServicoId", query = "SELECT i FROM ItemOS i WHERE i.itemOSPK.servicoId = :servicoId")
    , @NamedQuery(name = "ItemOS.findByValorServico", query = "SELECT i FROM ItemOS i WHERE i.valorServico = :valorServico")})
public class ItemOS implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ItemOSPK itemOSPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "valor_servico")
    private Double valorServico;
    @JoinColumn(name = "numero", referencedColumnName = "numero", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    //@ManyToOne(cascade=CascadeType.ALL)
    //@JoinColumn(name = "numero", referencedColumnName = "numero", insertable = false, updatable = false)
    private OrdemServico ordemServico;
    @JoinColumn(name = "servico_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Servico servico;

    public ItemOS() {
    }

    public ItemOS(ItemOSPK itemOSPK) {
        this.itemOSPK = itemOSPK;
    }

    public ItemOS(int numero, int servicoId) {
        this.itemOSPK = new ItemOSPK(numero, servicoId);
    }

    public ItemOSPK getItemOSPK() {
        return itemOSPK;
    }

    public void setItemOSPK(ItemOSPK itemOSPK) {
        this.itemOSPK = itemOSPK;
    }

    public Double getValorServico() {
        return valorServico;
    }

    public void setValorServico(Double valorServico) {
        this.valorServico = valorServico;
    }

    public OrdemServico getOrdemServico() {
        return ordemServico;
    }

    public void setOrdemServico(OrdemServico ordemServico) {
        this.ordemServico = ordemServico;
    }

    public Servico getServico() {
        return servico;
    }

    public void setServico(Servico servico) {
        this.servico = servico;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (itemOSPK != null ? itemOSPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ItemOS)) {
            return false;
        }
        ItemOS other = (ItemOS) object;
        if ((this.itemOSPK == null && other.itemOSPK != null) || (this.itemOSPK != null && !this.itemOSPK.equals(other.itemOSPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.ItemOS[ itemOSPK=" + itemOSPK + " ]";
    }
    
}
