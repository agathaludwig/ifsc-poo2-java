/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author agatha
 */
@Embeddable
public class ItemOSPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "numero")
    private int numero;
    @Basic(optional = false)
    @Column(name = "servico_id")
    private int servicoId;

    public ItemOSPK() {
    }

    public ItemOSPK(int numero, int servicoId) {
        this.numero = numero;
        this.servicoId = servicoId;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getServicoId() {
        return servicoId;
    }

    public void setServicoId(int servicoId) {
        this.servicoId = servicoId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) numero;
        hash += (int) servicoId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ItemOSPK)) {
            return false;
        }
        ItemOSPK other = (ItemOSPK) object;
        if (this.numero != other.numero) {
            return false;
        }
        if (this.servicoId != other.servicoId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.ItemOSPK[ numero=" + numero + ", servicoId=" + servicoId + " ]";
    }
    
}
