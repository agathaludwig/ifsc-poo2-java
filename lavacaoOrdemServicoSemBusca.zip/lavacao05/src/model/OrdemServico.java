/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author agatha
 */
@Entity
@Table(name = "ordemServico")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OrdemServico.findAll", query = "SELECT o FROM OrdemServico o")
    , @NamedQuery(name = "OrdemServico.findByNumero", query = "SELECT o FROM OrdemServico o WHERE o.numero = :numero")
    , @NamedQuery(name = "OrdemServico.findByAgenda", query = "SELECT o FROM OrdemServico o WHERE o.agenda = :agenda")
    , @NamedQuery(name = "OrdemServico.findByStatus", query = "SELECT o FROM OrdemServico o WHERE o.status = :status")
    , @NamedQuery(name = "OrdemServico.getUltimoNumero", query = "SELECT o FROM OrdemServico o ORDER BY o.numero DESC")})
public class OrdemServico implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "numero")
    private Integer numero;
    @Column(name = "agenda")
    @Temporal(TemporalType.DATE)
    private Date agenda;
    @Column(name = "horario")
    @Temporal(TemporalType.TIME)
    private Date horario;
    @Column(name = "status")
    private Boolean status;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ordemServico")
    private Collection<ItemOS> itemOSCollection;
    @JoinColumn(name = "veiculo_id", referencedColumnName = "id")
    @ManyToOne
    private Veiculo veiculoId;

    public OrdemServico() {
        this.itemOSCollection = new ArrayList<>();
    }

    public OrdemServico(Integer numero) {
        this.numero = numero;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public Date getAgenda() {
        return agenda;
    }

    public void setAgenda(Date agenda) {
        this.agenda = agenda;
    }
    
        public Date getHorario() {
        return horario;
    }

    public void setHorario(Date horario) { //???
        this.horario = horario;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @XmlTransient
    public Collection<ItemOS> getItemOSCollection() {
        return itemOSCollection;
    }

    public void setItemOSCollection(Collection<ItemOS> itemOSCollection) {
        this.itemOSCollection = itemOSCollection;
    }

    public Veiculo getVeiculoId() {
        return veiculoId;
    }

    public void setVeiculoId(Veiculo veiculoId) {
        this.veiculoId = veiculoId;
    }
    
    public void add (ItemOS item) {
        if (this.getItemOSCollection() == null) {
            this.itemOSCollection = new ArrayList<>();
        }
        this.itemOSCollection.add(item);
    }
    
    public void update (ItemOS item) {
        ArrayList<ItemOS> lista = (ArrayList<ItemOS>) this.itemOSCollection;
        lista.set(lista.indexOf(item), item);
    }

    public boolean delete (ItemOS item) {
        return this.itemOSCollection.remove(item);
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (numero != null ? numero.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrdemServico)) {
            return false;
        }
        OrdemServico other = (OrdemServico) object;
        if ((this.numero == null && other.numero != null) || (this.numero != null && !this.numero.equals(other.numero))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "OrdemServico [ numero=" + numero + " ]";
    }
    
}
